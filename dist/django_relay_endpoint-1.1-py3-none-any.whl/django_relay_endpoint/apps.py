from django.apps import AppConfig


class DjangoRelayEndpointConfig(AppConfig):
    name = 'django_relay_endpoint'
